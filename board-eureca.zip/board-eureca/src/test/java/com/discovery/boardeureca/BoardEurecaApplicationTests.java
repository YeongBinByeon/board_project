package com.discovery.boardeureca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardEurecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
