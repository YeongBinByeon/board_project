package com.cloud.boardgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
